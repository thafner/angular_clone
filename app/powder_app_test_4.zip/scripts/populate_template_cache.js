angular.module('powderApp.templates', []).run(['$templateCache', function($templateCache) {
  "use strict";
  $templateCache.put("views/content.html",
    "<div ng-controller=ContentCtrl><div class=section ng-swipe-left=\"goToPage('#/sect/0')\"><h2 ng-bind-html=sectionTitle>{{ sectionTitle }} test</h2><p ng-bind-html=sectionContent>{{ sectionContent }}</p></div></div>");
  $templateCache.put("views/footer.html",
    "<nav ng-controller=FooterCtrl><ul><li><a ng-click=\"goTo('/sect/0')\">Menu</a></li><li><a ng-click=\"goTo('/sect/1')\">Important Safety Information</a></li><li><a ng-click=\"goTo('/sect/2')\">Prescribing Information</a></li><li><a ng-click=\"goTo('/sect/3')\">Instructions For Use</a></li><li><a ng-click=\"goTo('/sect/4')\">References</a></li></ul></nav>");
  $templateCache.put("views/home.html",
    "<div ng-controller=HomeCtrl><div id=home ng-show=!showActions ng-swipe-left=goNext()><h2 ng-bind-html=homeTitle>{{ homeTitle }}</h2><div ng-bind-html=homeContent>{{ homeContent }}</div></div><a ng-click=\"goTo('/sect/1')\">test</a><p><a href=# target=_blank>blank test</a></p></div>");
}]);
