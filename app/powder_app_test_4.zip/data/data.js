var kuvanData = {
  'home' : '<span>Home Title</span>',
  'content' : 'Home Content',
  'next' : 0,
  'sections' : [
    {
      'title' : "Content 1 Title",
      'content' : 'Content 1 Content',
      'next' : 1,
      'prev' : 'home',
      'sub' : [
        
      ]
    },
    {
      'title' : "Content 2 Title",
      'content' : 'Content 2 Content',
      'next' : 2,
      'prev' : 0
    }
  ]
}